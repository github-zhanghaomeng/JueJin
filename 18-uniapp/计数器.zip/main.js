import Vue from 'vue'
import App from './App'
// 计数器
import sunUiStepper from './components/sunui-stepper/sunui-stepper.vue'
Vue.config.productionTip = false
Vue.component('sunui-stepper', sunUiStepper);
App.mpType = 'app'

const app = new Vue({
    ...App
})
app.$mount()
